import React from 'react';

const header5 = () => {
    return (
        <div>
            <h2>header5</h2>

        </div>
    );
};

export default header5;
