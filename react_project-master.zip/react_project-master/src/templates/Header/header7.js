import React from 'react';

const header7 = () => {
    return (
        <div>
            <h2>header7</h2>

        </div>
    );
};

export default header7;
