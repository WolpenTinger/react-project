import React from 'react';

const header8 = () => {
    return (
        <div>
            <h2>header8</h2>

        </div>
    );
};

export default header8;
