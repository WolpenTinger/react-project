import React from 'react';

const header6 = () => {
    return (
        <div>
            <h2>header6</h2>

        </div>
    );
};

export default header6;
