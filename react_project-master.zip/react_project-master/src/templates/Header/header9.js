import React from 'react';

const header9 = () => {
    return (
        <div>
            <h2>header9</h2>

        </div>
    );
};

export default header9;
