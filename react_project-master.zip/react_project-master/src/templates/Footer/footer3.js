import React from 'react';

const Footer3 = () => {
    return (
        <div>
            footer3
        </div>
    );
};

export default Footer3;