import React from 'react';

const Footer2 = () => {
    return (
        <div>
            footer2
        </div>
    );
};

export default Footer2;