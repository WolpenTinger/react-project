import React from 'react';

const Footer1 = () => {
    return (
        <div>
            footer1
        </div>
    );
};

export default Footer1;