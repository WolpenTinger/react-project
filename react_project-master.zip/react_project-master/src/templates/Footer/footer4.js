import React from 'react';

const Footer4 = () => {
    return (
        <div>
            footer4
        </div>
    );
};

export default Footer4;