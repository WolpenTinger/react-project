

//import React, { useState, useEffect } from "react";



//const MainWindow = ({ siteName }) => {

//    //const [siteName, setSiteName] = useState('');

//    //const handleGenerate = (name) => {
//    // setSiteName(name);
//    // };


//    return (
//        <div>
//            {siteName ? (
//                <div>
//                    <HeaderComponents title={siteName} randomIndex={randomNumHeader} />
//                    <BodyComponents content={siteName} randomIndex={randomNumBody} />
//                    <FooterComponents text={siteName} randomIndex={randomNumFooter} />
//                </div>
//            ) : (
//                <MainWindow onGenerate={handleGenerate} />
//            )}
//        </div>
//    );

//    {/*const randomNumHeader = GenerateNum(0, 4)
//    const randomNumBody = GenerateNum(0, 4)
//    const randomNumFooter = GenerateNum(0, 4)

//    console.log(randomNumHeader)
//    console.log(randomNumBody)
//    console.log(randomNumFooter)

//    return (
//        <div>
//            {/*<HeaderComponents randomIndex={randomNumHeader} />
//            <BodyComponents randomIndex={randomNumBody} />
//            <FooterComponents randomIndex={randomNumFooter} /> 
//            {<MainWindow/>}
//        </div>

       
//    );*/}
//};
//export default MainWindow;







